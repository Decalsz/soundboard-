# SCI-FI SOUNDBOARD STUDIO — Android Studio Project

Proyek ini membundel versi HTML soundboard ke dalam WebView Android dengan origin tetap:
`https://appassets.androidplatform.net/assets/index.html`.

Artinya IndexedDB milik app ini stabil dan tidak memakai `content://` dari ZArchiver. Pilih banyak audio juga didukung melalui file picker Android.

## Cara build APK di Android Studio

1. Install **Android Studio** dari https://developer.android.com/studio.
2. Extract folder proyek ini di penyimpanan perangkat/PC.
3. Buka Android Studio → **Open** → pilih folder `SCI-FI-SOUNDBOARD-STUDIO`.
4. Saat diminta, setujui **Trust Project** dan tunggu Gradle selesai download/sync.
5. Buka **SDK Manager** bila Android Studio meminta SDK Android 35, lalu install Android SDK Platform 35.
6. Untuk mengetes, sambungkan Android dengan USB debugging atau buat emulator, lalu tekan tombol **Run ▶**.
7. Untuk membuat APK: menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
8. APK debug ada di: `app/build/outputs/apk/debug/app-debug.apk`.
9. Untuk APK rilis: **Build → Generate Signed Bundle / APK → APK**, buat keystore baru dan simpan keystore/password dengan aman.

## Penting

- Data audio/playlist dari HTML yang dibuka lewat ZArchiver tidak dapat dipindah otomatis karena browser memakai storage origin berbeda.
- Setelah APK diinstal, import library satu kali dari dalam APK. Data berikutnya tersimpan di storage WebView aplikasi.
- Wrapper ini membuat app offline dan storage lebih stabil daripada `content://`. Background audio penuh/notification persisten tetap memerlukan port player ke Media3 native, bukan audio HTML/WebView.

## Cara paling mudah: build APK lewat GitHub (tanpa Android Studio)

1. Buat akun di https://github.com.
2. Tekan **New repository** dan beri nama bebas, misalnya `sci-fi-soundboard`.
3. Upload **seluruh isi folder** `SCI-FI-SOUNDBOARD-STUDIO` ke repository. Pastikan folder `.github` ikut ter-upload.
4. Buka tab **Actions** pada repository.
5. Pilih workflow **Build SCI-FI SOUNDBOARD STUDIO APK** lalu tekan **Run workflow**.
6. Tunggu proses hijau/selesai, biasanya beberapa menit saat pertama kali.
7. Buka hasil workflow → bagian **Artifacts** → download `SCI-FI-SOUNDBOARD-STUDIO-debug-APK`.
8. Extract ZIP artifact lalu install `app-debug.apk` di Android. Izinkan “Install unknown apps” jika Android meminta.
