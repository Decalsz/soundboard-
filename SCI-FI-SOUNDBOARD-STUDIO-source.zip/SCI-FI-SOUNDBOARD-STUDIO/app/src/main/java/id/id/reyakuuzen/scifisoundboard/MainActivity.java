package id.id.reyakuuzen.scifisoundboard;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;

public class MainActivity extends Activity {
    private static final int PICK_FILES = 42;
    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;
    private boolean audioPicker = true;
    private final Map<String, String> embeddedArt = new HashMap<>();
    private NativePlaybackService playback;
    private boolean bound;
    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) {
            playback = ((NativePlaybackService.LocalBinder)b).getService(); bound = true;
            playback.setListener((index, position, duration, playing, title) -> sendPlayback(index, position, duration, playing, title));
        }
        @Override public void onServiceDisconnected(ComponentName n) { bound=false; playback=null; }
    };
    public class AndroidBridge {
        @JavascriptInterface public String artworkFor(String filename) { String art=embeddedArt.get(filename); return art==null?"":art; }
        @JavascriptInterface public void playQueue(String json, int index) { runOnUiThread(() -> { if(playback==null)return; try { JSONArray a=new JSONArray(json); ArrayList<String> q=new ArrayList<>(); for(int i=0;i<a.length();i++)q.add(a.getString(i)); playback.playQueue(q,index); }catch(Exception ignored){} }); }
        @JavascriptInterface public void pauseNative() { runOnUiThread(()->{if(playback!=null)playback.pause();}); }
        @JavascriptInterface public void resumeNative() { runOnUiThread(()->{if(playback!=null)playback.resume();}); }
        @JavascriptInterface public void stopNative() { runOnUiThread(()->{if(playback!=null)playback.stopPlayback();}); }
        @JavascriptInterface public void nextNative() { runOnUiThread(()->{if(playback!=null)playback.next();}); }
        @JavascriptInterface public void previousNative() { runOnUiThread(()->{if(playback!=null)playback.previous();}); }
        @JavascriptInterface public void seekNative(long position) { runOnUiThread(()->{if(playback!=null)playback.seek(position);}); }
        @JavascriptInterface public void volumeNative(float volume) { runOnUiThread(()->{if(playback!=null)playback.volume(volume);}); }
    }
    private void sendPlayback(int index,long pos,long dur,boolean active,String title) {
        if(webView==null)return; String safe=title.replace("\\","\\\\").replace("'","\\'");
        webView.post(() -> webView.evaluateJavascript("window.NativePlayer&&window.NativePlayer.update("+index+","+pos+","+dur+","+active+",'"+safe+"')", null));
    }
    @SuppressLint("SetJavaScriptEnabled") @Override public void onCreate(Bundle state) {
        super.onCreate(state); if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 9); setContentView(R.layout.activity_main);
        startService(new Intent(this, NativePlaybackService.class)); bindService(new Intent(this, NativePlaybackService.class), connection, Context.BIND_AUTO_CREATE);
        webView=findViewById(R.id.soundboard_webview); WebSettings set=webView.getSettings();
        set.setJavaScriptEnabled(true); set.setDomStorageEnabled(true); set.setDatabaseEnabled(true); set.setMediaPlaybackRequiresUserGesture(true); set.setAllowFileAccess(true); set.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(),"AndroidBridge"); webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(uploadCallback!=null)uploadCallback.onReceiveValue(null);uploadCallback=cb;String mime="*/*";for(String type:p.getAcceptTypes()){if(type==null)continue;String x=type.toLowerCase();if(x.startsWith("image/")){mime="image/*";break;}if(x.startsWith("audio/"))mime="audio/*";}audioPicker=!mime.startsWith("image/");Intent pick;if(audioPicker){pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("audio/*");pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);}else{pick=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);pick.setType("image/*");}pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);try{startActivityForResult(Intent.createChooser(pick,audioPicker?"Import audio":"Choose cover from gallery"),PICK_FILES);}catch(Exception e){uploadCallback.onReceiveValue(null);uploadCallback=null;}return true;}});
        webView.loadUrl("file:///android_asset/index.html");
    }
    private String displayName(Uri uri){Cursor c=null;try{c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null);if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}finally{if(c!=null)c.close();}return uri.getLastPathSegment();}
    private void rememberAudio(Uri uri,String name){try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}getSharedPreferences("native_audio",MODE_PRIVATE).edit().putString("uri_"+name,uri.toString()).apply();try{String bare=name.replaceFirst("\\.[^.]+$","");getSharedPreferences("native_audio",MODE_PRIVATE).edit().putString("uri_"+bare,uri.toString()).apply();MediaMetadataRetriever r=new MediaMetadataRetriever();r.setDataSource(this,uri);byte[] art=r.getEmbeddedPicture();if(art!=null)embeddedArt.put(name,"data:image/jpeg;base64,"+Base64.encodeToString(art,Base64.NO_WRAP));r.release();}catch(Exception ignored){}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=PICK_FILES||uploadCallback==null)return;ArrayList<Uri> us=new ArrayList<>();if(result==RESULT_OK&&data!=null){if(data.getClipData()!=null)for(int i=0;i<data.getClipData().getItemCount();i++)us.add(data.getClipData().getItemAt(i).getUri());else if(data.getData()!=null)us.add(data.getData());}if(audioPicker)for(Uri u:us)rememberAudio(u,displayName(u));uploadCallback.onReceiveValue(us.toArray(new Uri[0]));uploadCallback=null;}
    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(bound)unbindService(connection);super.onDestroy();}
}
