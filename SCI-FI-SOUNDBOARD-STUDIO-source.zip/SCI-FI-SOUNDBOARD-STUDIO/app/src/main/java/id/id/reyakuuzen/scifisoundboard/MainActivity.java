package id.id.reyakuuzen.scifisoundboard;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int PICK_FILES = 42;
    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;
    private boolean audioPicker = true;
    private final Map<String, String> embeddedArt = new HashMap<>();

    public class AndroidBridge {
        @JavascriptInterface public String artworkFor(String filename) {
            String art = embeddedArt.get(filename);
            return art == null ? "" : art;
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.soundboard_webview);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                String mime = "*/*";
                String[] accepted = params.getAcceptTypes();
                if (accepted != null) for (String type : accepted) {
                    if (type == null) continue;
                    String lower = type.toLowerCase();
                    if (lower.startsWith("image/")) { mime = "image/*"; break; }
                    if (lower.startsWith("audio/")) mime = "audio/*";
                }
                audioPicker = !mime.startsWith("image/");
                Intent pick;
                if (!audioPicker) {
                    // Cover art opens the Android gallery/photos provider instead of a file browser.
                    pick = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    pick.setType("image/*");
                } else {
                    // Audio stays in the document picker and supports Select All / multiple files.
                    pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType("audio/*");
                    pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivityForResult(Intent.createChooser(pick, audioPicker ? "Import audio" : "Choose cover from gallery"), PICK_FILES); }
                catch (Exception error) { uploadCallback.onReceiveValue(null); uploadCallback = null; }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private String displayName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) return cursor.getString(0);
        } catch (Exception ignored) {} finally { if (cursor != null) cursor.close(); }
        String path = uri.getLastPathSegment();
        return path == null ? "" : path;
    }

    private void readEmbeddedArt(Uri uri, String name) {
        try {
            MediaMetadataRetriever retriever = new MediaMetadataRetriever();
            retriever.setDataSource(this, uri);
            byte[] picture = retriever.getEmbeddedPicture();
            retriever.release();
            if (picture != null && picture.length > 0)
                embeddedArt.put(name, "data:image/jpeg;base64," + Base64.encodeToString(picture, Base64.NO_WRAP));
        } catch (Exception ignored) { }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_FILES || uploadCallback == null) return;
        ArrayList<Uri> uris = new ArrayList<>();
        if (result == RESULT_OK && data != null) {
            if (data.getClipData() != null) for (int i=0;i<data.getClipData().getItemCount();i++) uris.add(data.getClipData().getItemAt(i).getUri());
            else if (data.getData() != null) uris.add(data.getData());
        }
        if (audioPicker) for (Uri uri : uris) readEmbeddedArt(uri, displayName(uri));
        uploadCallback.onReceiveValue(uris.toArray(new Uri[0]));
        uploadCallback = null;
    }

    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
