package id.id.reyakuuzen.scifisoundboard;

import android.content.Context;
import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.util.Base64;
import androidx.annotation.Nullable;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;
import androidx.media3.session.DefaultMediaNotificationProvider;
import java.util.ArrayList;
import java.util.List;

public class NativePlaybackService extends MediaSessionService {
    public interface Listener { void onNativePlayback(int index, long position, long duration, boolean playing, String title); }
    public class LocalBinder extends Binder { NativePlaybackService getService() { return NativePlaybackService.this; } }
    private final IBinder binder = new LocalBinder();
    private ExoPlayer player;
    private MediaSession session;
    private Listener listener;
    private final ArrayList<String> names = new ArrayList<>();

    @Override public void onCreate() {
        super.onCreate();
        player = new ExoPlayer.Builder(this).build();
        DefaultMediaNotificationProvider notifications = new DefaultMediaNotificationProvider(this);
        notifications.setSmallIcon(R.drawable.app_icon_cat);
        setMediaNotificationProvider(notifications);
        session = new MediaSession.Builder(this, player).build();
        player.addListener(new Player.Listener() {
            @Override public void onEvents(Player p, Player.Events events) { notifyUi(); }
            @Override public void onMediaItemTransition(@Nullable MediaItem item, int reason) { notifyUi(); }
        });
    }
    @Nullable @Override public MediaSession onGetSession(MediaSession.ControllerInfo info) { return session; }
    @Override public IBinder onBind(Intent intent) { super.onBind(intent); return binder; }
    public void setListener(Listener value) { listener = value; notifyUi(); }
    public void playQueue(List<String> trackNames, int index) {
        names.clear(); names.addAll(trackNames);
        ArrayList<MediaItem> list = new ArrayList<>();
        for (String name : trackNames) {
            String raw = getSharedPreferences("native_audio", Context.MODE_PRIVATE).getString("uri_" + name, null);
            if (raw == null) continue;
            Uri uri = Uri.parse(raw);
            MediaMetadata.Builder meta = new MediaMetadata.Builder().setTitle(name).setArtist("SCI-FI SOUNDBOARD STUDIO");
            try { MediaMetadataRetriever r = new MediaMetadataRetriever(); r.setDataSource(this, uri); byte[] art = r.getEmbeddedPicture(); if (art != null) meta.setArtworkData(art, MediaMetadata.PICTURE_TYPE_FRONT_COVER); r.release(); } catch (Exception ignored) {}
            list.add(new MediaItem.Builder().setUri(uri).setMediaMetadata(meta.build()).build());
        }
        if (list.isEmpty()) return;
        player.setMediaItems(list, Math.max(0, Math.min(index, list.size()-1)), 0);
        player.prepare(); player.play(); notifyUi();
    }
    public void pause() { player.pause(); notifyUi(); }
    public void resume() { player.play(); notifyUi(); }
    public void stopPlayback() { player.stop(); player.seekTo(0); notifyUi(); }
    public void seek(long ms) { player.seekTo(ms); notifyUi(); }
    public void volume(float value) { player.setVolume(Math.max(0, Math.min(1, value))); }
    public void next() { if (player.hasNextMediaItem()) player.seekToNextMediaItem(); else player.pause(); }
    public void previous() { if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem(); else player.seekTo(0); }
    private void notifyUi() { if (listener == null || player == null) return; int i=Math.max(0,player.getCurrentMediaItemIndex()); String title=i<names.size()?names.get(i):""; listener.onNativePlayback(i,player.getCurrentPosition(),Math.max(0,player.getDuration()),player.isPlaying(),title); }
    @Override public void onDestroy() { if(session!=null)session.release(); if(player!=null)player.release(); super.onDestroy(); }
}
